# etl/__init__.py
# makes 'etl' a package so we can do 'from etl.models import Series', etc.
