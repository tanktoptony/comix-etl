from datetime import datetime
from typing import Dict, Any

def normalize_issue_number(num) -> str | None:
    if num is None:
        return None
    # Marvel sends numbers as float or int sometimes
    try:
        # Preserve variants like 1.1 as "1.1"
        return str(num).strip()
    except Exception:
        return None

def cents_from_price(price) -> int | None:
    if price is None:
        return None
    try:
        return int(round(float(price) * 100))
    except Exception:
        return None

def to_date(s: str | None):
    if not s:
        return None
    # Expecting "YYYY-MM-DD" from Marvel's dates (coverDate)
    try:
        return datetime.strptime(s, "%Y-%m-%d").date()
    except Exception:
        return None

def map_marvel_comic_to_rows(series_row: Dict[str, Any], comic: Dict[str, Any]):
    issue = {
        "series_id": series_row["series_id"],
        "issue_number": normalize_issue_number(comic.get("issueNumber")),
        "cover_date": to_date(next((d.get("date") for d in comic.get("dates", []) if d.get("type") == "coverDate"), None)),
        "price_cents": cents_from_price(next((p.get("price") for p in comic.get("prices", []) if p.get("type") == "printPrice"), None)),
        "isbn": comic.get("isbn"),
        "upc": comic.get("upc"),
        "description": comic.get("description"),
    }
    creators = []
    for c in comic.get("creators", {}).get("items", []):
        name = (c.get("name") or "").strip()
        role = (c.get("role") or "").strip()
        if name:
            creators.append({"name": name, "role": role})
    return issue, creators
