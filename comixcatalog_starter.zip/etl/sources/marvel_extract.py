import requests, math
from etl.utils import marvel_auth_params, log

BASE = "https://gateway.marvel.com/v1/public"

def get_series_by_title(title: str, limit: int = 20):
    params = {**marvel_auth_params(), "title": title, "limit": min(limit, 100), "offset": 0}
    r = requests.get(f"{BASE}/series", params=params, timeout=30)
    r.raise_for_status()
    data = r.json()["data"]
    log.info("Found %s series for title='%s' (count=%s)", len(data["results"]), title, data["count"])
    return data["results"]

def get_comics_for_series(series_id: int, max_items: int = 200):
    items, offset, page_size = [], 0, 100
    while offset < max_items:
        params = {**marvel_auth_params(), "series": series_id, "limit": page_size, "offset": offset, "orderBy": "issueNumber"}
        r = requests.get(f"{BASE}/comics", params=params, timeout=30)
        r.raise_for_status()
        data = r.json()["data"]
        batch = data["results"]
        items.extend(batch)
        log.info("Fetched %s comics (offset=%s)", len(batch), offset)
        if len(batch) < page_size:
            break
        offset += page_size
    return items
