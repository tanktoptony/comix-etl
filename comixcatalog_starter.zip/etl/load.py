from sqlalchemy.orm import Session
from sqlalchemy import select
from etl.models import Publisher, Series, Creator, Issue, IssueCreator

def get_or_create(session: Session, model, defaults=None, **kwargs):
    inst = session.execute(select(model).filter_by(**kwargs)).scalar_one_or_none()
    if inst:
        return inst, False
    params = dict(kwargs)
    if defaults:
        params.update(defaults)
    inst = model(**params)
    session.add(inst)
    session.flush()
    return inst, True

def load_series_husk(session: Session, title: str, source_key: str | None, source_system: str | None, publisher_name: str | None = None):
    publisher = None
    if publisher_name:
        publisher, _ = get_or_create(session, Publisher, name=publisher_name)
    series, created = get_or_create(session, Series, title=title, source_key=source_key, source_system=source_system)
    if publisher and series.publisher_id is None:
        series.publisher_id = publisher.publisher_id
    return series

def upsert_issue_with_creators(session: Session, series_id: int, issue_row: dict, creators: list[dict]):
    # Issue
    issue = session.execute(
        select(Issue).where(Issue.series_id == series_id, Issue.issue_number == issue_row.get("issue_number"))
    ).scalar_one_or_none()
    if issue is None:
        issue = Issue(**issue_row)
        session.add(issue)
        session.flush()
    else:
        # update a few mutable fields
        for k in ("cover_date", "price_cents", "isbn", "upc", "description"):
            setattr(issue, k, issue_row.get(k))
    # Creators
    for c in creators:
        creator, _ = get_or_create(session, Creator, name=c["name"])
        ic = session.execute(
            select(IssueCreator).where(IssueCreator.issue_id == issue.issue_id, IssueCreator.creator_id == creator.creator_id, IssueCreator.role == c.get("role") or "")
        ).scalar_one_or_none()
        if ic is None:
            session.add(IssueCreator(issue_id=issue.issue_id, creator_id=creator.creator_id, role=c.get("role") or ""))
    return issue
