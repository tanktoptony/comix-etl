import hashlib, time, os, logging

log = logging.getLogger("comix")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

def marvel_auth_params():
    ts = str(int(time.time()))
    public = os.environ.get("MARVEL_PUBLIC_KEY")
    private = os.environ.get("MARVEL_PRIVATE_KEY")
    if not public or not private:
        raise RuntimeError("MARVEL_PUBLIC_KEY / MARVEL_PRIVATE_KEY not set")
    hash_ = hashlib.md5((ts + private + public).encode()).hexdigest()
    return {"ts": ts, "apikey": public, "hash": hash_}
