from __future__ import annotations
from sqlalchemy import String, Integer, Date, Text, ForeignKey
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship, sessionmaker
from sqlalchemy import create_engine
import os

class Base(DeclarativeBase):
    pass

class Publisher(Base):
    __tablename__ = "publisher"
    publisher_id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String, unique=True, nullable=False)
    series: Mapped[list["Series"]] = relationship(back_populates="publisher")

class Series(Base):
    __tablename__ = "series"
    series_id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    title: Mapped[str] = mapped_column(Text, nullable=False)
    publisher_id: Mapped[int | None] = mapped_column(ForeignKey("publisher.publisher_id"))
    start_year: Mapped[int | None] = mapped_column(Integer)
    volume: Mapped[int | None] = mapped_column(Integer)
    source_key: Mapped[str | None] = mapped_column(Text)
    source_system: Mapped[str | None] = mapped_column(Text)
    publisher: Mapped["Publisher"] = relationship(back_populates="series")
    issues: Mapped[list["Issue"]] = relationship(back_populates="series")

class Creator(Base):
    __tablename__ = "creator"
    creator_id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(Text, nullable=False)

class Issue(Base):
    __tablename__ = "issue"
    issue_id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    series_id: Mapped[int] = mapped_column(ForeignKey("series.series_id"))
    issue_number: Mapped[str | None] = mapped_column(String)
    cover_date: Mapped[object | None] = mapped_column(Date)
    price_cents: Mapped[int | None] = mapped_column(Integer)
    isbn: Mapped[str | None] = mapped_column(String)
    upc: Mapped[str | None] = mapped_column(String)
    description: Mapped[str | None] = mapped_column(Text)
    series: Mapped["Series"] = relationship(back_populates="issues")

class IssueCreator(Base):
    __tablename__ = "issue_creator"
    issue_id: Mapped[int] = mapped_column(ForeignKey("issue.issue_id"), primary_key=True)
    creator_id: Mapped[int] = mapped_column(ForeignKey("creator.creator_id"), primary_key=True)
    role: Mapped[str] = mapped_column(String, primary_key=True)

class EtlRun(Base):
    __tablename__ = "etl_run"
    run_id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    source_system: Mapped[str | None] = mapped_column(String)
    started_at: Mapped[object | None] = mapped_column()
    finished_at: Mapped[object | None] = mapped_column()
    records_read: Mapped[int | None] = mapped_column(Integer)
    records_loaded: Mapped[int | None] = mapped_column(Integer)
    status: Mapped[str | None] = mapped_column(String)
    notes: Mapped[str | None] = mapped_column(Text)

_engine = None

def get_engine():
    global _engine
    if _engine is None:
        url = os.getenv("DATABASE_URL")
        if not url:
            raise RuntimeError("DATABASE_URL not set")
        _engine = create_engine(url, pool_pre_ping=True)
    return _engine

SessionLocal = sessionmaker(bind=get_engine())
