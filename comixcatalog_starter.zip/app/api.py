from dotenv import load_dotenv
load_dotenv()

from flask import Flask, request, jsonify
from etl.models import get_engine, Base, Series, Issue
from sqlalchemy.orm import Session
from sqlalchemy import select

app = Flask(__name__)

@app.get("/series")
def series_search():
    q = request.args.get("q", "").strip()
    with Session(get_engine()) as s:
        stmt = select(Series).where(Series.title.ilike(f"%{q}%")).limit(50)
        rows = s.scalars(stmt).all()
        return jsonify([{"series_id": r.series_id, "title": r.title} for r in rows])

@app.get("/series/<int:series_id>/issues")
def series_issues(series_id: int):
    with Session(get_engine()) as s:
        stmt = select(Issue).where(Issue.series_id == series_id).order_by(Issue.issue_number)
        rows = s.scalars(stmt).all()
        return jsonify([{"issue_number": r.issue_number, "cover_date": r.cover_date.isoformat() if r.cover_date else None} for r in rows])

if __name__ == "__main__":
    app.run(debug=True)
